# 一式をダウンロード

**[MIA_visualizer_bundle.zip](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/docs/visualizer/downloads/MIA_visualizer_bundle.zip)** を保存して展開してください。最初に開く教材は `MIA_5query_cards.html` です。

現行3つのHTML、4回版PDF、案内・詳しい説明、旧表示、固定コード、サイズ記録、検証記録を含みます。フォルダ構成を保って展開すると、資料内のリンクも使えます。HTMLの操作にはサーバー起動や追加データの読み込みは不要です。

[資料の入口へ戻る](../README.md)
