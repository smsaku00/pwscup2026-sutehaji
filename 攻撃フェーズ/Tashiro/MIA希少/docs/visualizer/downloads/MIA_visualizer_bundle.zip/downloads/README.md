# 一式をダウンロード（図解教材）

**ここに含まれる固定5回教材は、大会で第3回に提出した固定5bitとは別の質問列です。** 実スコアを教材の平均復号に入力して所属を判断しないでください。[実提出の設定](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/MIA/20261008_%E7%AC%AC3%E5%9B%9EMIA_%E5%9B%BA%E5%AE%9A5bit%E3%81%A8%E9%9D%9E%E4%BC%9A%E5%93%A1%E8%BC%83%E6%AD%A3/README.md)／[教材の違い](../README.md)。

**[MIA_visualizer_bundle.zip](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/docs/visualizer/downloads/MIA_visualizer_bundle.zip)** を保存して展開してください。最初に開く教材は `MIA_5query_cards.html` です。

現行3つのHTML、4回版PDF、案内・詳しい説明、旧表示、固定コード、サイズ記録、検証記録を含みます。フォルダ構成を保って展開すると、資料内のリンクも使えます。HTMLの操作にはサーバー起動や追加データの読み込みは不要です。

[資料の入口へ戻る](../README.md)
