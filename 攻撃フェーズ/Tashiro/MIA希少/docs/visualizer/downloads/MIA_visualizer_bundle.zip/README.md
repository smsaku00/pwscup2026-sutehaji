# MIA希少の図解資料（教材と実提出を区別）

> **【実提出との区別・2026-10-08】** 非適応5回版は学習用の例を表示します。**その例のID・点数を大会の実提出・公式得点と取り違えないでください。** 第3回に使用した固定候補と第4〜7回の正本は[共通MIAの仕様](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/MIA/20261008_%E7%AC%AC3%E5%9B%9EMIA_%E5%9B%BA%E5%AE%9A5bit%E3%81%A8%E9%9D%9E%E4%BC%9A%E5%93%A1%E8%BC%83%E6%AD%A3/%E8%AA%AC%E6%98%8E.md)。適応4回ビューアは比較方式です。

**初めて見る方は[固定5回版の教材](MIA_5query_cards.html)で仕組みを確認できます。ただし教材の5bit符号は、第3回に実提出した5bit符号とは異なります。** 所属候補が結果により絞られる様子を示す仮想例であり、実提出CSV、実採点の復号、今後の第4〜7回の質問選択には用いません。

| 区分 | 最初の質問で高側にする未知候補ID | 扱い |
|---|---|---|
| **実提出・第3回** | **115、169、264、383、462** | 共通MIAの原本が正本 |
| **この教材の第1問** | **76、169、264、462、675** | 教材専用。実提出ではない |

実提出した第3回の質問と今後の第4〜7回は、[共通MIAの設定](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/MIA/20261008_%E7%AC%AC3%E5%9B%9EMIA_%E5%9B%BA%E5%AE%9A5bit%E3%81%A8%E9%9D%9E%E4%BC%9A%E5%93%A1%E8%BC%83%E6%AD%A3/%E8%AA%AC%E6%98%8E.md)を確認してください。実採点の `mia.tpr_rare` を読み取るときは[共通MIAの結果読取器](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/MIA/20261008_%E7%AC%AC3%E5%9B%9EMIA_%E5%9B%BA%E5%AE%9A5bit%E3%81%A8%E9%9D%9E%E4%BC%9A%E5%93%A1%E8%BC%83%E6%AD%A3/%E7%B5%90%E6%9E%9C%E8%AA%AD%E5%8F%96.py)だけを使い、教材内部の復号表へ実スコアを流用しないでください。

| 見たい内容 | 開く資料 |
|---|---|
| 教材専用の固定5回（実提出と別の符号）を理解する | **[非適応5回版・現在の教材](MIA_5query_cards.html)** |
| 結果に応じて提出を変える、追加4回の全分岐を見る | [適応4回版・完全決定木](MIA_4query_tree.html) |
| 4回版の読み方を図で確認する | [4回版のガイドPDF](MIA_4query_tree_guide.pdf) |
| 従来の適応5回案を確認する | [適応5回版・参考資料](MIA_5query_adaptive.html) |

## 開き方

一式を使う場合は、**[配布ZIP](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/docs/visualizer/downloads/MIA_visualizer_bundle.zip)** を保存して展開し、`MIA_5query_cards.html` をブラウザで開きます。個別のHTMLはGitHubの **Download raw file** で保存して開けます。各HTMLは単体で動きます。

非適応5回版は、まず **⓪ 5回に振り分ける** を表示します。1レコードの「含める／含めない」を横に見て、含める列の下へ同じIDを入れます。11行を列ごとに集めると、各提出の対象IDになります。「IDを振り分ける」→「次のレコードを見る」は手動で、「11レコードを順に再生」だけ自動です。

続いて①の全体表と②の候補の絞り込みを切り替えられます。「次の提出結果を表示」→「この結果で候補を絞る」は手動です。「5回の結果を順に表示」だけ自動で進みます。表示される所属IDと結果は説明用の例です。⓪に戻ると結果の自動再生は止まり、表示中の結果を残します。

## その他の資料

| 場所 | 内容 |
|---|---|
| [resources/](resources/) | [詳しい操作方法・計算の根拠・検証記録への案内](resources/DETAILS.md)、固定コード、サイズ記録 |
| [archive/](archive/) | 以前の足し算表示・55マス表示・長い旧資料 |
| [downloads/](downloads/) | HTML・PDF・説明書・データ・検証記録をまとめた配布ZIP |

現行3つのHTMLと4回版PDFの場所・ファイル名はそのままです。生成・検証のプログラムは [tools/visualizer/](https://github.com/smsaku00/pwscup2026-sutehaji/tree/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/tools/visualizer)、元証明書は [analysis/full_depth4_20261007/](https://github.com/smsaku00/pwscup2026-sutehaji/tree/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/analysis/full_depth4_20261007) にあります。
