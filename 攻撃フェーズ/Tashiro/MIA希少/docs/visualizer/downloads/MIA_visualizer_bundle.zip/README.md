# MIA希少の図解資料

**初めて見る方は、[非適応5回版の教材](MIA_5query_cards.html)から始めてください。** 提出結果をチームごとに読み、1人の候補行・2人組の候補線を絞る流れを確認できます。

| 見たい内容 | 開く資料 |
|---|---|
| 固定5回の提出を、1から理解する | **[非適応5回版・現在の教材](MIA_5query_cards.html)** |
| 結果に応じて提出を変える、追加4回の全分岐を見る | [適応4回版・完全決定木](MIA_4query_tree.html) |
| 4回版の読み方を図で確認する | [4回版のガイドPDF](MIA_4query_tree_guide.pdf) |
| 従来の適応5回案を確認する | [適応5回版・参考資料](MIA_5query_adaptive.html) |

## 開き方

一式を使う場合は、**[配布ZIP](https://github.com/smsaku00/pwscup2026-sutehaji/blob/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/docs/visualizer/downloads/MIA_visualizer_bundle.zip)** を保存して展開し、`MIA_5query_cards.html` をブラウザで開きます。個別のHTMLはGitHubの **Download raw file** で保存して開けます。各HTMLは単体で動きます。

非適応5回版では、①の全体表と②の候補の絞り込みを切り替えられます。「次の提出結果を表示」→「この結果で候補を絞る」は手動です。「5回の結果を順に表示」だけ自動で進みます。表示される所属IDと結果は説明用の例です。

## その他の資料

| 場所 | 内容 |
|---|---|
| [resources/](resources/) | [詳しい操作方法・計算の根拠・検証記録への案内](resources/DETAILS.md)、固定コード、サイズ記録 |
| [archive/](archive/) | 以前の足し算表示・55マス表示・長い旧資料 |
| [downloads/](downloads/) | HTML・PDF・説明書・データ・検証記録をまとめた配布ZIP |

現行3つのHTMLと4回版PDFの場所・ファイル名はそのままです。生成・検証のプログラムは [tools/visualizer/](https://github.com/smsaku00/pwscup2026-sutehaji/tree/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/tools/visualizer)、元証明書は [analysis/full_depth4_20261007/](https://github.com/smsaku00/pwscup2026-sutehaji/tree/main/%E6%94%BB%E6%92%83%E3%83%95%E3%82%A7%E3%83%BC%E3%82%BA/Tashiro/MIA%E5%B8%8C%E5%B0%91/analysis/full_depth4_20261007) にあります。
